export class Sub_Section
{
    Sub_Section_Id:number;
    Sub_Section_Name:string;
    Selection:boolean
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

