export class Application_Course
{
    Course_Name:string;
    Application_details_Id:number;


constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

