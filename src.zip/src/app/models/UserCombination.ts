export class UserCombination
{
    UserCombination_Id:number;
    UserCombination_Name:string;


constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

