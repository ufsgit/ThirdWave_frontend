export class Gender
{
Gender_Id:number;
Gender_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

