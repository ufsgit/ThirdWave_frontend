export class Passport
{
Passport_Id:number;
Passport_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

