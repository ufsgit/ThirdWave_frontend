export class qualification_master
{
    Qualification_Master_Id:number;
    Qualification_Name:string;
    Qualification_Selection:boolean;
   
    
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

