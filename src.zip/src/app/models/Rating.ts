export class Rating
{
    Rating_Id:number;
    Rating_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

