export class Student_Fields
{

    Student_Fields_Id: number;
    Fields_Id:number;
    Fields_Name: string;  
    Data: string;


    data_field_Acc_no: string;


constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

