
export class Student_Import_Details
{

Name:string;
Email:string
Mobile:string
Last_Name:string;
Gender:string;
Address1:string;
Address2:string;
Pincode:string;
Alternative_Email:string;
// Phone_Number:string;
Alternative_Phone_Number: string;
Facebook: string;
Whatsapp: string;
College_University:string
Programme_Course:string
Intake:string
Year:string
Reference:string
Visa_Submission_Date:string
Activity:string
Visa_Outcome:string
Agent:string
Status_Details:string
Remarks:string
Date :string;
User_Id:number;
User_Name:string;


Slno:string;
Enquiry_Date:string;
Consultant:string;
Client_Name:string;
Mobile_Number:string;
City:string;
Job_Title:string;
Program_Name:string;
Next_Action_Remarks:string;
Lead_Source:string;

Alternate_Phone:string;
Lead_Stage:string;
Description:string;
Lost_Remarks:string;
Admission_Date:string;
Lead_Count:string;
Lost_Date:string;
Live_Update:string;
Lost_Reason:string;
Next_Action_Date:String;
Next_Action_Date_temp:Date;
Branch:string;
Business:string;
Street1:string;
Street2:string;
State:string;

Post_Office:string;
Fees:string;

Date_of_Birth:string;
Education_Qualification:string;
Stream:string;
Year_of_Passing:string;
College:string;
Status:string;
Experience:string;
Contacted_Date:string;
Created_Username:string;
Created_Time:string;
Updated_Username:string;
Updated_Time:string;
Viewed_Username:string;
Viewed_Time:string;


Registration_Date:Date;
Student_Name:string;
Country:string;
Counsilor:string;
Probable_Intake:string;
Enquiry_Source:string;
Applied_Via:string;
Department:string;
Owner:string;

Enquiry_Source_Name:string;
Department_Status_Name:string;




constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

