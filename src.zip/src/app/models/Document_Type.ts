export class Document_Type
{
    Document_Type_Id:number;
    Document_Type_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

