export class AgentManagement {
    AgentManagement_Id: number;
    AgentManagement_Name: string;

    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}