export class MOI
{
MOI_Id:number;
MOI_Name:string;
// Ielts_Minimum_Score:number;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

