export class Colors {
    Colors_Id:number;
    Colors_Name :string;
    constructor(values: Object = {}) {
        Object.assign(this, values)
    }
}

