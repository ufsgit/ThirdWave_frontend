export class Class
{
    Class_Id:number;
    Class_Name:string;
    Class_Order:number;


constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

