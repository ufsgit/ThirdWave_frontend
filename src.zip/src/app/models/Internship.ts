export class Internship
{
Internship_Id:number;
Internship_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

