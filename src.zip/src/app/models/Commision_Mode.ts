export class Commision_Mode
{
Commision_Mode_Id:number;
Commision_Mode_Name:string;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

