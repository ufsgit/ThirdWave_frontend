export class User_Type
{
User_Type_Id:number;
User_Type_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

