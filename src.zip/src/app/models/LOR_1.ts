export class LOR_1
{
LOR_1_Id:number;
LOR_1_Name:string;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

