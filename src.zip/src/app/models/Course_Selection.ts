export class Course_Selection
{
Course_Id:number;
Course_Name:string;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

