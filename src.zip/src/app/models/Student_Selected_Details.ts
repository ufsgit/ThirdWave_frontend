
export class Student_Selected_Details
{

Student_Id:number;
Application_details_Id:number;
Check_Box_View:Boolean;




constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

