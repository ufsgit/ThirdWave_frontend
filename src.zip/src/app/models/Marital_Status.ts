export class Marital_Status
{
Marital_Status_Id:number;
Marital_Status_Name:string;
// Ielts_Minimum_Score:number;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

