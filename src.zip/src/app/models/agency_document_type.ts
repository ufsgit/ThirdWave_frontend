export class agency_document_type
{
    agency_documents_id: number;
    agency_documents_name: string;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

