export class Process_Department
{

    Process_Department_id:number;
    Process_Status_Details_id:number;

    Department_Id:number;
    Department_Name: string;  
    // checkbox_view:boolean;
    checkbox_view3:boolean;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

