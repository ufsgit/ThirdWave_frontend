export class Process {
    Process_Name: string;
    Process_Id: number;
    Order_IN: number;
    Color: string;
  }